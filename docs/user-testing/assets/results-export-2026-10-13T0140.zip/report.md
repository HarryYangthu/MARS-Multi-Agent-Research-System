# 研究结果

研究问题：继续上一轮研究 run 2026\-10\-11T1824\_pimc\_ca\_sparsity\_g1c17（报告 runs/2026\-10\-11T1824\_pimc\_ca\_sparsity\_g1c17/writing/research\_report\.approved\.md）。唯一目标：检验载波分辨族基项纳入带外镜像族后的消融效果。  【实验设置】在其余条件与上一轮完全一致：单频 group1 case17，16 通道数据 \(16,30720\)，seed 42，相同训练预算 3588 次参数更新，保留 PP 频率先验，K=1 对照与基线角色定义不变，build\_L1C 保持 false（与 ca\_pp\_2term 一致，以隔离族基项效应）。  【新增配置】configs/singleband\_g1\_c17\_ca\_pp\_3term\.yaml：三项 ca\_terms = full 锚点 \+ IM3 族 \[\[1,2\],\[0,\-1\]\]（2c1\-c0）\+ 带外镜像族 \[\[0,2\],\[1,\-1\]\]；pp\_shifts\_mhz = \-107\.7 \[host path\] \-27\.509 \[host path\] \-162\.494。可参照 configs/singleband\_g1\_c17\_ca\_pp\_keepL1C\.yaml（其中已含第 3 项与对应 shift，但该文件 build\_L1C:true，仅作 shift/族参考，不作为本轮主配置）。  【核对要点】上一轮已知模板 configs/singleband\_g1\_c17\_ca\_pp\.yaml 原为 3 项但被裁剪为 2 项，本轮需恢复第 3 项并核对族中心与 shift 自洽。主控已核对：carriers\_mhz = \[\-9\.799,4\.927\] \[host path\] \[35\.196,4\.916\]；2\*c0\-c1 = \-54\.794 = \-162\.494 \+ f\_rx\(107\.7\)；2\*c1\-c0 = 80\.191 = \-27\.509 \+ 107\.7。请下游再次在代码/配置中校验一致性（tests/test\_mars\_train\_protocol\.py 的 shift 一致性用例为参考）。  【比较对象与指标】ca\_pp\_3term 与上一轮 ca\_pp\_2term 比较 improvement\_db \[host path\] RES \[host path\] maxRES \[host path\] PER\_THD 与参数量（实数等效量）。  【基线与 K=1 对照复用】若协议允许（相同数据、配置、seed），优先直接复用上一轮实测 evaluation\.json 并注明来源；仅当协议要求必须同轮重跑时才重跑。  【达标口径】沿用上一轮：参数量实数等效量 ≤ 基线 6784 的 80%（5427\.2）且 improvement\_db 不劣于基线 17\.175；同时报告 3term 相对 2term 的净差值。

流程状态：流程已完成；状态来源：已保存的权威状态
目标结果：目标尚不能判定
没有经过独立验证的目标判定；完成流程不等于目标达成。

## 测量记录

| 实验 | 作业标识 | 指标 | 数值 | 单位 | 方向 | 实验角色 | 回执 | 来源索引 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | improvement\_db | 17\.175160361876557 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | parameters\_real\_equivalent | 6784\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | active\_parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | PIM | 22\.42093277725835 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | RES | 5\.2457724153817935 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | maxRES | 9\.187769333342615 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | PER\_THD | 18\.69 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | rx\_rank | 12\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | optimizer\_steps | 3289\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | covered\_points | 24564\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | declared\_points | 24576\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| A\_baseline\_rerun | e3fedb7c1dbd4cff91a088e035226974 | seconds | 392\.60218299995176 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | improvement\_db | 17\.18968102106459 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | active\_parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | PIM | 22\.42093277725835 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | RES | 5\.231251756193761 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | maxRES | 9\.012835861787451 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | PER\_THD | 18\.71 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | rx\_rank | 12\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | optimizer\_steps | 3289\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | covered\_points | 24564\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | declared\_points | 24576\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| B\_ca\_pp\_2term | 1a9da08782ae44d3a1d3c8c8217945a9 | seconds | 530\.7690344000002 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | improvement\_db | 17\.209843163132383 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | active\_parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | PIM | 22\.42093277725835 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | RES | 5\.211089614125969 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | maxRES | 9\.3696444376059 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | PER\_THD | 18\.74 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | rx\_rank | 12\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | optimizer\_steps | 3289\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | covered\_points | 24564\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | declared\_points | 24576\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| C\_ca\_pp\_3term | a3fac473a8c647ebafa0b190b826e75a | seconds | 456\.5850514000049 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | improvement\_db | 17\.175160361876557 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | active\_parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | PIM | 22\.42093277725835 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | RES | 5\.2457724153817935 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | maxRES | 9\.187769333342615 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | PER\_THD | 18\.69 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | rx\_rank | 12\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | optimizer\_steps | 3289\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | covered\_points | 24564\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | declared\_points | 24576\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |
| D\_ca\_k1\_control | 9ab8f6b3522a42f895bdcf1ee362d009 | seconds | 349\.5780587999616 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0029 |

## 作业与条件

| 实验 | 角色 | 作业状态 | 回执 | 耗时（秒） | 记录的随机种子 | 请求步数 |
| --- | --- | --- | --- | --- | --- | --- |
| A\_baseline\_rerun | 未声明 | 流程已完成 | 回执已核验 | 421\.51500000001397 | 42 | 3588 |
| B\_ca\_pp\_2term | 未声明 | 流程已完成 | 回执已核验 | 551\.3279999999795 | 42 | 3588 |
| C\_ca\_pp\_3term | 未声明 | 流程已完成 | 回执已核验 | 487\.98499999998603 | 42 | 3588 |
| D\_ca\_k1\_control | 未声明 | 流程已完成 | 回执已核验 | 375\.0 | 42 | 3588 |

## 描述性统计

| 实验 | 指标 | 已核验作业数 | 均值 | 样本标准差 |
| --- | --- | --- | --- | --- |
| A\_baseline\_rerun | improvement\_db | 1 | 17\.175160361876557 | 未知 / 缺失 |
| A\_baseline\_rerun | parameters\_real\_equivalent | 1 | 6784\.0 | 未知 / 缺失 |
| A\_baseline\_rerun | active\_parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| A\_baseline\_rerun | PIM | 1 | 22\.42093277725835 | 未知 / 缺失 |
| A\_baseline\_rerun | RES | 1 | 5\.2457724153817935 | 未知 / 缺失 |
| A\_baseline\_rerun | maxRES | 1 | 9\.187769333342615 | 未知 / 缺失 |
| A\_baseline\_rerun | PER\_THD | 1 | 18\.69 | 未知 / 缺失 |
| A\_baseline\_rerun | rx\_rank | 1 | 12\.0 | 未知 / 缺失 |
| A\_baseline\_rerun | optimizer\_steps | 1 | 3289\.0 | 未知 / 缺失 |
| A\_baseline\_rerun | covered\_points | 1 | 24564\.0 | 未知 / 缺失 |
| A\_baseline\_rerun | declared\_points | 1 | 24576\.0 | 未知 / 缺失 |
| A\_baseline\_rerun | seconds | 1 | 392\.60218299995176 | 未知 / 缺失 |
| B\_ca\_pp\_2term | improvement\_db | 1 | 17\.18968102106459 | 未知 / 缺失 |
| B\_ca\_pp\_2term | parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| B\_ca\_pp\_2term | active\_parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| B\_ca\_pp\_2term | PIM | 1 | 22\.42093277725835 | 未知 / 缺失 |
| B\_ca\_pp\_2term | RES | 1 | 5\.231251756193761 | 未知 / 缺失 |
| B\_ca\_pp\_2term | maxRES | 1 | 9\.012835861787451 | 未知 / 缺失 |
| B\_ca\_pp\_2term | PER\_THD | 1 | 18\.71 | 未知 / 缺失 |
| B\_ca\_pp\_2term | rx\_rank | 1 | 12\.0 | 未知 / 缺失 |
| B\_ca\_pp\_2term | optimizer\_steps | 1 | 3289\.0 | 未知 / 缺失 |
| B\_ca\_pp\_2term | covered\_points | 1 | 24564\.0 | 未知 / 缺失 |
| B\_ca\_pp\_2term | declared\_points | 1 | 24576\.0 | 未知 / 缺失 |
| B\_ca\_pp\_2term | seconds | 1 | 530\.7690344000002 | 未知 / 缺失 |
| C\_ca\_pp\_3term | improvement\_db | 1 | 17\.209843163132383 | 未知 / 缺失 |
| C\_ca\_pp\_3term | parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| C\_ca\_pp\_3term | active\_parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| C\_ca\_pp\_3term | PIM | 1 | 22\.42093277725835 | 未知 / 缺失 |
| C\_ca\_pp\_3term | RES | 1 | 5\.211089614125969 | 未知 / 缺失 |
| C\_ca\_pp\_3term | maxRES | 1 | 9\.3696444376059 | 未知 / 缺失 |
| C\_ca\_pp\_3term | PER\_THD | 1 | 18\.74 | 未知 / 缺失 |
| C\_ca\_pp\_3term | rx\_rank | 1 | 12\.0 | 未知 / 缺失 |
| C\_ca\_pp\_3term | optimizer\_steps | 1 | 3289\.0 | 未知 / 缺失 |
| C\_ca\_pp\_3term | covered\_points | 1 | 24564\.0 | 未知 / 缺失 |
| C\_ca\_pp\_3term | declared\_points | 1 | 24576\.0 | 未知 / 缺失 |
| C\_ca\_pp\_3term | seconds | 1 | 456\.5850514000049 | 未知 / 缺失 |
| D\_ca\_k1\_control | improvement\_db | 1 | 17\.175160361876557 | 未知 / 缺失 |
| D\_ca\_k1\_control | parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| D\_ca\_k1\_control | active\_parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| D\_ca\_k1\_control | PIM | 1 | 22\.42093277725835 | 未知 / 缺失 |
| D\_ca\_k1\_control | RES | 1 | 5\.2457724153817935 | 未知 / 缺失 |
| D\_ca\_k1\_control | maxRES | 1 | 9\.187769333342615 | 未知 / 缺失 |
| D\_ca\_k1\_control | PER\_THD | 1 | 18\.69 | 未知 / 缺失 |
| D\_ca\_k1\_control | rx\_rank | 1 | 12\.0 | 未知 / 缺失 |
| D\_ca\_k1\_control | optimizer\_steps | 1 | 3289\.0 | 未知 / 缺失 |
| D\_ca\_k1\_control | covered\_points | 1 | 24564\.0 | 未知 / 缺失 |
| D\_ca\_k1\_control | declared\_points | 1 | 24576\.0 | 未知 / 缺失 |
| D\_ca\_k1\_control | seconds | 1 | 349\.5780587999616 | 未知 / 缺失 |

## 事实

- 已校验 4 项本地作业的身份、请求/结果哈希及测量文件。

## 假设（非测量结论）

- 尚未记录。

## 解释

- 存在 schema 合规的 Writing 文档；文档内容本身不作为实验有效或目标达成证明。

## 局限

- 单次测量不提供统计显著性；只对相同声明配置/命令计算描述性波动，未认证数据与协议匹配或统计独立性。
- 作业回执校验验证已存证据一致性，不证明训练协议科学有效或完成独立复现。
- 原始私有数据、完整源码、原始日志、模型上下文和凭据不进入默认离线包。
- 未绑定可信测量回执的旧领域或远端结果保留未验证，不推断执行成功。

## 外部复现前提

- 原始授权代码、数据划分、冻结配置与运行环境需由项目持有人另行提供。
- 需在独立环境重跑声明的基线/候选并按预先约定容差核对。

![Recorded curve 1](curves/curve-001.svg)

![Recorded curve 2](curves/curve-002.svg)

![Recorded curve 3](curves/curve-003.svg)

![Recorded curve 4](curves/curve-004.svg)

## 离线文件

- [完整 JSON](results.json)
- [指标 CSV](metrics.csv)
- [实验 CSV](experiments.csv)
- [描述性统计 CSV](statistics.csv)
- [来源哈希索引](evidence/sources.json)
- [复现前提](reproduction.json)
- [校验清单](manifest.json)

## 资源与协议

[资源用量、已声明协议与状态记录见完整 JSON](results.json)。预算预留不等于实际消耗；协议声明不等于已执行条件。
