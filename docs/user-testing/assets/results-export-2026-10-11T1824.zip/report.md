# 研究结果

研究问题：在单频 group1 case17 上,能否利用单频 TX 实为双载波\(载波带宽 5 或 10 MHz,位于大于 60 MHz 的下行带内\)导致的频域稀疏先验,在保留 PP 频率先验的前提下,用按实测双载波中心构造的载波分辨 PP 族基项替换基线的单一全带代表项,使 evaluation\.json 的 improvement\_db 不劣于同条件基线且参数实数等效量不高于基线的 80%,或使 improvement\_db 相对基线提升不低于 2 dB?

流程状态：流程已完成；状态来源：已保存的权威状态
目标结果：目标尚不能判定
没有经过独立验证的目标判定；完成流程不等于目标达成。

## 测量记录

| 实验 | 作业标识 | 指标 | 数值 | 单位 | 方向 | 实验角色 | 回执 | 来源索引 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | improvement\_db | 17\.175160361876557 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | parameters\_real\_equivalent | 6784\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | active\_parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | PIM | 22\.42093277725835 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | RES | 5\.2457724153817935 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | maxRES | 9\.187769333342615 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | PER\_THD | 18\.69 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | rx\_rank | 12\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | optimizer\_steps | 3289\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | covered\_points | 24564\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | declared\_points | 24576\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| baseline\_rerun | bd7d57bae30b4107ac8494cf2caf0586 | seconds | 266\.52811720001046 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0002 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | improvement\_db | 17\.175160361876557 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | active\_parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | PIM | 22\.42093277725835 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | RES | 5\.2457724153817935 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | maxRES | 9\.187769333342615 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | PER\_THD | 18\.69 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | rx\_rank | 12\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | optimizer\_steps | 3289\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | covered\_points | 24564\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | declared\_points | 24576\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_k1\_degenerate\_control | 8cafae8530944f488fc08c9f4956c68c | seconds | 485\.26803849998396 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0011 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | improvement\_db | 17\.18968102106459 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | active\_parameters\_real\_equivalent | 4704\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | PIM | 22\.42093277725835 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | RES | 5\.231251756193761 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | maxRES | 9\.012835861787451 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | PER\_THD | 18\.71 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | rx\_rank | 12\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | optimizer\_steps | 3289\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | covered\_points | 24564\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | declared\_points | 24576\.0 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |
| ca\_pp\_2term | 1c3ba61d25a047c896c416a06ee6bd29 | seconds | 326\.97009580000304 | 未知 / 缺失 | 未知 / 缺失 | 未声明 | 回执已核验 | source\_0020 |

## 作业与条件

| 实验 | 角色 | 作业状态 | 回执 | 耗时（秒） | 记录的随机种子 | 请求步数 |
| --- | --- | --- | --- | --- | --- | --- |
| baseline\_rerun | 未声明 | 流程已完成 | 回执已核验 | 290\.06299999996554 | 42 | 3588 |
| ca\_k1\_degenerate\_control | 未声明 | 流程已完成 | 回执已核验 | 523\.6089999999385 | 42 | 3588 |
| ca\_pp\_2term | 未声明 | 流程已完成 | 回执已核验 | 354\.3279999999795 | 42 | 3588 |

## 描述性统计

| 实验 | 指标 | 已核验作业数 | 均值 | 样本标准差 |
| --- | --- | --- | --- | --- |
| baseline\_rerun | improvement\_db | 1 | 17\.175160361876557 | 未知 / 缺失 |
| baseline\_rerun | parameters\_real\_equivalent | 1 | 6784\.0 | 未知 / 缺失 |
| baseline\_rerun | active\_parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| baseline\_rerun | PIM | 1 | 22\.42093277725835 | 未知 / 缺失 |
| baseline\_rerun | RES | 1 | 5\.2457724153817935 | 未知 / 缺失 |
| baseline\_rerun | maxRES | 1 | 9\.187769333342615 | 未知 / 缺失 |
| baseline\_rerun | PER\_THD | 1 | 18\.69 | 未知 / 缺失 |
| baseline\_rerun | rx\_rank | 1 | 12\.0 | 未知 / 缺失 |
| baseline\_rerun | optimizer\_steps | 1 | 3289\.0 | 未知 / 缺失 |
| baseline\_rerun | covered\_points | 1 | 24564\.0 | 未知 / 缺失 |
| baseline\_rerun | declared\_points | 1 | 24576\.0 | 未知 / 缺失 |
| baseline\_rerun | seconds | 1 | 266\.52811720001046 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | improvement\_db | 1 | 17\.175160361876557 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | active\_parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | PIM | 1 | 22\.42093277725835 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | RES | 1 | 5\.2457724153817935 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | maxRES | 1 | 9\.187769333342615 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | PER\_THD | 1 | 18\.69 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | rx\_rank | 1 | 12\.0 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | optimizer\_steps | 1 | 3289\.0 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | covered\_points | 1 | 24564\.0 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | declared\_points | 1 | 24576\.0 | 未知 / 缺失 |
| ca\_k1\_degenerate\_control | seconds | 1 | 485\.26803849998396 | 未知 / 缺失 |
| ca\_pp\_2term | improvement\_db | 1 | 17\.18968102106459 | 未知 / 缺失 |
| ca\_pp\_2term | parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| ca\_pp\_2term | active\_parameters\_real\_equivalent | 1 | 4704\.0 | 未知 / 缺失 |
| ca\_pp\_2term | PIM | 1 | 22\.42093277725835 | 未知 / 缺失 |
| ca\_pp\_2term | RES | 1 | 5\.231251756193761 | 未知 / 缺失 |
| ca\_pp\_2term | maxRES | 1 | 9\.012835861787451 | 未知 / 缺失 |
| ca\_pp\_2term | PER\_THD | 1 | 18\.71 | 未知 / 缺失 |
| ca\_pp\_2term | rx\_rank | 1 | 12\.0 | 未知 / 缺失 |
| ca\_pp\_2term | optimizer\_steps | 1 | 3289\.0 | 未知 / 缺失 |
| ca\_pp\_2term | covered\_points | 1 | 24564\.0 | 未知 / 缺失 |
| ca\_pp\_2term | declared\_points | 1 | 24576\.0 | 未知 / 缺失 |
| ca\_pp\_2term | seconds | 1 | 326\.97009580000304 | 未知 / 缺失 |

## 事实

- 已校验 3 项本地作业的身份、请求/结果哈希及测量文件。

## 假设（非测量结论）

- 基线单频分支把 16 通道 TX 当作整带信号处理:libs/Model\.py 中 terms 只有 A,只有一项显式频移 \-107\.7 MHz,share\_L30\_across\_terms 默认关闭,build\_L1C 默认打开但 forward 仅在 NbandTx 大于 2 时调用 L1C,单频前向不使用它。实际发射谱只占两个窄载波,与整带处理不匹配。按子带 DPD 的载波分辨基函数,用 tools/estimate\_carriers\.py 在真实 MAT 上估计的双载波中心 c0 与 c1\(模板值约 \-9\.799 与 \+35\.196 MHz\)构造族基项:保留 0 阶 full 作为基线锚点,并加入落入观察带的 IM3 族 2c1\-c0\(族中心约 80\.191 MHz,配 shift 等于族中心减 f\_rx 即 107\.7,得约 \-27\.509 MHz,与 eval\_centers\_mhz 的 \-27\.5 重合\);同时共享 L30 并关闭单频前向未调用的 L1C,则该模型可在 improvement\_db 不劣于同条件基线的同时把 parameters\_real\_equivalent 降到基线实测值的约 69%,或在同参数量下取得更大的对消增益。必须如实说明:参数量下降完全来自关闭未被单频前向调用的 L1C 分支;在共享 L30 时载波分辨基项本身对参数量是中性的,载波分辨项的净效果必须由 K=1 退化对照隔离。

## 解释

- 存在 schema 合规的 Writing 文档；文档内容本身不作为实验有效或目标达成证明。

## 局限

- 单次测量不提供统计显著性；只对相同声明配置/命令计算描述性波动，未认证数据与协议匹配或统计独立性。
- 作业回执校验验证已存证据一致性，不证明训练协议科学有效或完成独立复现。
- 原始私有数据、完整源码、原始日志、模型上下文和凭据不进入默认离线包。
- 未绑定可信测量回执的旧领域或远端结果保留未验证，不推断执行成功。
- 模型账本包含未知用量，完整 token 与费用合计保持未知；预留额度不冒充实际消耗。

## 外部复现前提

- 原始授权代码、数据划分、冻结配置与运行环境需由项目持有人另行提供。
- 需在独立环境重跑声明的基线/候选并按预先约定容差核对。

![Recorded curve 1](curves/curve-001.svg)

![Recorded curve 2](curves/curve-002.svg)

![Recorded curve 3](curves/curve-003.svg)

## 离线文件

- [完整 JSON](results.json)
- [指标 CSV](metrics.csv)
- [实验 CSV](experiments.csv)
- [描述性统计 CSV](statistics.csv)
- [来源哈希索引](evidence/sources.json)
- [复现前提](reproduction.json)
- [校验清单](manifest.json)

## 资源与协议

[资源用量、已声明协议与状态记录见完整 JSON](results.json)。预算预留不等于实际消耗；协议声明不等于已执行条件。
